class GraphRepr:
    def __init__(self):
        self.graph = []
        
    def __repr__(self):
        return str(self.graph)

    def add_vertex(self):
        pass
    
    def add_edge(self, idx1, idx2):
        pass

    def get_neighbors(self, idx):
        pass
