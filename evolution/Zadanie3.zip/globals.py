INPUT_FILENAME = 'objects.txt'
SIMULATION_CONF_FILENAME = 'simulation.json'
INT_CHECK_INDEXES = [0, 2, 3]
